var express = require("express");
var bodyParser = require("body-parser");
var morgan = require("morgan");
var mongoose = require("mongoose");
var methodOverride = require("method-override");
var flash = require("connect-flash");
var session = require("express-session");
var fs = require("fs");
var path = require("path");
var config = require('./config/passport');
var passport = require('passport');
var port = process.env.PORT || 3000;
var app = express();
var morgan=require('morgan');

app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true
}));
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())
app.set("view engine", "ejs");
app.set('views', __dirname + '/views');
app.set('public', __dirname + '/public');
app.engine('html', require('ejs').renderFile);
app.use(methodOverride("_method"))
app.use(flash())
app.use(morgan('dev'))
app.use(session({secret: "MySecret"})) // session 생성 코드

// Server 연결
app.listen(3000, () => {
    console.log(`Express is running on port ${port}!`)
})

// DB 연결
var Client = require('mongodb').MongoClient;
Client.connect('mongodb://localhost:27017/MISS', { useNewUrlParser: true }, (error, db) => {
    if(error) {
        console.log(error);
    } else {
        console.log("connected to mongodb server!");
        db.close();
    }
});

app.get('/login', (req, res) => {
    res.render('Login.html')
})

app.get('/main', (req, res) => {
    res.render('MAIN.html')
})

app.get('/compatition', (req, res) => {
    res.render('COMPATITION.html')
})

app.get('/board/coding', (req, res) => {
    res.render('FB_code.html')
})

app.get('/board/game', (req, res) => {
    res.render('FB_game.html')
})

app.get('/board/buy', (req, res) => {
    res.render('FB_sub.html')
})

app.get('/board/etc', (req, res) => {
    res.render('FB_etc.html')
})


app.use("/main", require('./router/main_list'))
app.use("/demerit/school", require('./router/demerit/school'))
app.get("/demerit/dormitory", require('./router/demerit/dormitory'))
app.use("/board/coding", require('./router/board/coding'))
app.use("/board/game", require('./router/board/game'))
app.use("/board/buy", require('./router/board/buy'))
app.use("/board/etc", require('./router/board/etc'))
app.use("/competition", require('./router/competition'))
app.use("/user", require('./router/user'))

app.use(passport.initialize()) // passport 초기화
app.use(passport.session()) // passport session 연결

var flash = require('connect-flash')
app.use(flash())

app.use((req, res, next) => {
    res.locals.currentUser = req.user;
    next() // 다음으로 진행
})
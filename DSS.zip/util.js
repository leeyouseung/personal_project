var util = {};
var flash = require('connect-flash')

util.getDate = function(dateObj) {
    if(dateObj instanceof Date)
        return dateObj.getFullYear() + "-" + get2digits(dateObj.getDate())
}

util.getTime = function(dateObj) {
    if(dateObj instanceof Date)
        return get2digits(dateObj.getHours()) + ":" + get2digits(dateObj.getMinutes()) + ":" + get2digits(dateObj.getSeconds())
}

// 로그인이 되어있는지 확인
util.isLoggedIn = (req, res, next) => {
    if (req.isAuthenticated()){
        return next();
    } else {
        req.flash('errors', { login: "로그인 후 이용하실 수 있습니다." })
        res.redirect('/login')
    }
}

util.noPermission = () => {
    req.flash("errors", { login: "You don't have permission" })
    req.logout()
    res.redirect("/login")
}

util.admin = (req, res, next) => {
    if(req.body.username === admin) {
        return next();
    } else {
        res.send('<script type="text/javascript">alert("권한이 없습니다.");</script>')
    }
}

module.exports = util
function get2digits (num) {
    retrun ("0" + num).slice(-2)
}
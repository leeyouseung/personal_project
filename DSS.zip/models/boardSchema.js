var mongoose = require("mongoose")

var boardSchema = mongoose.Schema({
    username: { type: String },
    title: { type: String, require: [true, "제목을 입력해주세요."] },
    contents: { type: String, require: [true, "내용을 입력해주세요."] },
    category: { type: String, require: [true, "카테고리를 지정해주세요."] },
    createdAt: { type: Date, default: Date.now },
    comments: [{
        username: { type: String },
        memo: { type: String, require: [true, "내용을 입력해주세요."] },
        date: { type: Date, default: Date.now }
    }],
    count: { type: Number, default: 0 },
    updated: [{
        contents: { type: String },
        updatedAt: { type: Date }
    }],
    deleted: { type: Boolean, default: false } // true == 삭제
})

boardSchema.virtual("createdDate")
.get(() => {
    return util.getDate(this.createdAt)
})

boardSchema.virtual("createdTime")
.get(() => {
    return util.getTime(this.createdAt)
})

boardSchema.virtual("updatedDate")
.get(() => {
    return getDate(this.updatedAt)
})

boardSchema.virtual("updatedTime")
.get(() => {
    return getTime(this.updatedAt)
})

var Board = mongoose.model("BoardContents", boardSchema)
module.exports = Board
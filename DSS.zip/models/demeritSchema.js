var mongoose = require("mongoose")

var demeritSchema = mongoose.Schema({
    username: { type: String },
    name: { type: String },
    date: { type: String, require: true },
    reason: { type: String, require: true },
    score: { type: Number, require: true },
    category: { type: Number, require: true }
})

module.exports = mongoose.model('demerit', demeritSchema)
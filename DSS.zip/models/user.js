var mongoose = require('mongoose')
var Schema = mongoose.Schema
var bcrypt = require("bcrypt-nodejs")

// Schema 정의
var userSchema = mongoose.Schema({
    "username": {
        type: String, 
        require: [true, "ID를 입력해주세요."],
        trim: true,
        unique: true,
    },
	"password": {
        type: String, 
        require: [true, "비밀번호를 입력해주세요."],
        select: false
    }
})

// 비밀번호 암호화
userSchema.methods.validPassword = (password) => {
    return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null)
}

// 비밀번호 유효성 검증
userSchema.methods.validPassword = (password) => {
    return bcrypt.compareSync(password, this.local.password)
}

userSchema.virtual("passwordConfirmation")
.get(function(){ return this._passwordConfirmation })
.set(function(value){ this._passwordConfirmation=value })

userSchema.virtual("originalPassword")
.get(function(){ return this._originalPassword })
.set(function(value){ this._originalPassword=value })

userSchema.virtual("currentPassword")
.get(function(){ return this._currentPassword })
.set(function(value){ this._currentPassword=value })

userSchema.virtual("newPassword")
.get(function(){ return this._newPassword })
.set(function(value){ this._newPassword=value })

userSchema.path("password").validate(function(v) {
    var user = this;

    if(!user.isNew) {
     if(!user.currentPassword) {
      user.invalidate("currentPassword", "Current Password is required!")
     }
     if(!user.newPassword) {
        user.invalidate("newPassword", "New Password is required!")
     }
     if(!user.passwordConfirmation) {
         user.invalidate("passwordConfirmation", "Password Confirmation is required!")
     }
     if(user.currentPassword && user.currentPassword != user.originalPassword){
      user.invalidate("currentPassword", "Current Password is invalid!");
     }
     if(user.newPassword !== user.passwordConfirmation) {
      user.invalidate("passwordConfirmation", "Password Confirmation does not matched!");
     }
    }
   });

module.exports = mongoose.model('User', userSchema)
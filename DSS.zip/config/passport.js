var passport = require("passport")
var LocalStrategy = require("passport-local").Strategy
var user = require('../models/user')

module.exports = (passport) => {
    // user의 id만 session에 저장
    passport.serializeUser((user, done) => {
    done(null, user.id)
    })
    // 매번 요청이 올 때마다 user 정보를 db에서 새로 읽어옴
    passport.deserializeUser((id, done) => {
        user.findById(id, (err, user) => {
           done(err, user)
        })
    })
}

passport.use('login', new LocalStrategy({
    usernameField: 'username',
    passwordField: 'password',
    passReqToCallback: true
}, (req, username, password, done) => {
    user.findOne({ 'username': username }, (err, user) => {
        if(err) return done(err)
        if(!user)
            return done(null, false, req.flash('loginMessage', '사용자를 찾을 수 없습니다.'))
        if(!user.validPassword(password))
            return done(null, false, req.flash('loginMessage', '비밀번호가 다릅니다.'))
        return done(null, user)
    })
}))

module.exprots = passport;
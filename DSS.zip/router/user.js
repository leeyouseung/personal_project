var express = require("express")
var router = express.Router()
var User = require('../models/user')
var util = require('../util')


router.get('/user', util.isLoggedIn, (req, res) => {
    User.findOne({ username: req.params.username }, (err, user) => {
        if(err) return res.json(err)
        res.render('passwordChange.html', { user: user })
    })
})

router.put('/:username', (req, res, next) => {
    User.findOne({ username: req.params.username })
    .select("password")
    .exec((err, user) => {
        if(err) return res.json(err)

        user.originalPassword = user.originalPassword
        user.password = req.body.newPassword? req.body.newPassword : user.password
        for(var p in req.body) {
            user[p] = req.body[p]
        }

        user.save((err, user) => {
            if(err) return res.json(err)
            res.redirect('/' + req.params.username + '/edit')
        })
    })
})

module.exports = router
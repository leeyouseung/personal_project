var express = require("express")
var router = express.Router();
var Contents = require('../models/boardSchema')

router.get('/main', (req, res) => {
    var page = req.param('page')
    if(page == null) {
        page = 1
    }

    var skipSize = (page-1)*5;
    var limitSize = 5;
    var pageNum = 1;

    buyContents.count({ deleted: false }, (err, totalCount) => {
        if(err) throw err;

        pageNum = Math.ceil(totalCount/limitSize)
        buyContents.find({})
        .sort({ date: -1 })
        .exec((err, rawContents) => {
            if(err) throw err;
            res.render('board', {
                title: "Main",
                contents: rawContents
            })
        })
    })
})

module.exports = router
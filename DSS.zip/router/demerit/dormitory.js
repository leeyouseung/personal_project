var express = require("express")
var router = express.Router();
var demeritDormitory = require('../../models/demeritSchema')
var util = require('../../util')

router.get('/demerit/dormitory', (req, res) => {
    res.render('demeritSchool.html')
})

module.exports = router
var express = require("express")
var router = express.Router();
var demeritSchool = require('../../models/demeritSchema')
var util = require('../../util')

router.get('/demerit/school', util.isLoggedIn, (req, res) => {
    demeritSchool.find({ username: req.body.username })
    res.render('demerit_school/show')
})

module.exports = router
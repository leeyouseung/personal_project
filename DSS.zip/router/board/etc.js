var express = require("express")
var router = express.Router();
var etcContents = require('../../models/boardSchema')
var util = require('../../util')

// 글 목록
router.get('/board/etc', (req, res) => {
    var page = req.param('page')
    if(page == null) {
        page = 1
    }

    var skipSize = (page-1)*5;
    var limitSize = 5;
    var pageNum = 1;

    buyContents.count({ deleted: false }, (err, totalCount) => {
        if(err) throw err;

        pageNum = Math.ceil(totalCount/limitSize)
        buyContents.find({ category: etc })
        .sort({ date: -1 })
        .exec((err, rawContents) => {
            if(err) throw err;
            res.render('board', {
                title: "BoardEtc",
                contents: rawContents
            })
        })
    })
})

// 글 작성 form
router.get('/board/etc/new', util.isLoggedIn, (req, res) => {
    res.render('board/new') // 게시물 작성 form url 변경하기
})

// 글 작성
router.post('/board/etc', (req, res) => {
    etcContents.create(req.body, (err, post) => {
        if(err) return res.json(err)
        res.redirect('/board/etc')
    })
})

// 글 읽기
router.get('/board/etc/:id', (req, res) => {
    etcContents.findOne({ _id: req.params.id }, (err, post) => {
        if(err) return res.json(err)
        res.render('board/show', { post: post }) // 게시물 읽어오는 view url 변경하기
    })
})

// 글 수정 form
router.get('/board/etc/:id/edit', util.isLoggedIn, (req, res) => {
    etcContents.findOne({ _id: req.params.id }, (err, post) => {
        if(err) return res.json(err);
        res.render('board/edit', { post: post }) // 게시물 수정 form url 변경하기
    })
})

// 글 수정
router.put('/board/etc/:id', (req, res) => {
    etcContents.findOneAndUpdate({ _id: req.params.id }, req. body, (err, post) => {
        if(err) return res.json(err)
        res.redirect('/board/etc/' + req.params.id)
    })
})

// 글 삭제
router.delete('/board/etc/:id', util.isLoggedIn, (req, res) => {
    etcContents.remove({ _id: req.params.id }, (err) => {
        if(err) return res.json(err)
        res.redirect("/board/etc")
    })
})

module.exports = router
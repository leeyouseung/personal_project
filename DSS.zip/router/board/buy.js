var express = require("express")
var router = express.Router();
var buyContents = require('../../models/boardSchema')
var util = require('../../util')

// 글 목록
router.get('/board/buy', (req, res) => {
    var page = req.param('page')
    if(page == null) {
        page = 1
    }

    var skipSize = (page-1)*5;
    var limitSize = 5;
    var pageNum = 1;

    buyContents.count({ deleted: false }, (err, totalCount) => {
        if(err) throw err;

        pageNum = Math.ceil(totalCount/limitSize)
        buyContents.find({ category: buy })
        .sort({ date: -1 })
        .exec((err, rawContents) => {
            if(err) throw err;
            res.render('board', {
                title: "BoardBuy",
                contents: rawContents
            })
        })
    })
})

// 글 작성 form
router.get('/board/buy/new', util.isLoggedIn, (req, res) => {
    res.render('board/new') // 게시물 작성 form url 변경하기
})

// 글 작성
router.post('/board/buy', (req, res) => {
    buyContents.create(req.body, (err, post) => {
        if(err) return res.json(err)
        res.redirect('/board/buy')
    })
})

// 글 읽기
router.get('/board/buy/:id', (req, res) => {
    buyContents.findOne({ _id: req.params.id }, (err, post) => {
        if(err) return res.json(err)
        res.render('board/show', { post: post }) // 게시물 읽어오는 view url 변경하기
    })
})

// 글 수정 form
router.get('/board/buy/:id/edit', util.isLoggedIn, (req, res) => {
    buyContents.findOne({ _id: req.params.id }, (err, post) => {
        if(err) return res.json(err);
        res.render('board/edit', { post: post }) // 게시물 수정 form url 변경하기
    })
})

// 글 수정
router.put('/board/buy/:id', (req, res) => {
    buyContents.findOneAndUpdate({ _id: req.params.id }, req. body, (err, post) => {
        if(err) return res.json(err)
        res.redirect('/board/buy/' + req.params.id)
    })
})

// 글 삭제
router.delete('/board/buy/:id', util.isLoggedIn, (req, res) => {
    buyContents.remove({ _id: req.params.id }, (err) => {
        if(err) return res.json(err)
        res.redirect("/board/buy")
    })
})

module.exports = router
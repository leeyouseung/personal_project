var passport = require("passport")

router.post('/login', passport.authenticate('login', {
    successRedirect: '/main',
    failureRedirect: '/login',
    failureRedirect: true
}))